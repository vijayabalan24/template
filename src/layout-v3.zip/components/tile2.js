import React from 'react'
class Tile2 extends React.Component{
   
    render(){
        //console.log(this.props.tiledata)
        return(
            <>
                {this.props.tiledata.map((ls,index) =>
                    <>
                    <p>{ls.name}</p>
                    <p>{ls.img}</p>
                    </>
                )}
            </>
        )
    }
}   
export default Tile2