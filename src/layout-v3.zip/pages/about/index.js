import React from 'react'
import Tile1 from '../../components/tile1'
class About extends React.Component{
    
    render(){
        return(
            <>
                <section className="home__banner"></section>
                    
               <style jsx>
                   {
                       `
                       .home__banner{background:url('hero.jpg') no-repeat;min-height:200px;background: url(hero.jpg) no-repeat; min-height: 200px; background-position: center center; background-position: left; background-size: cover;}
                       .hp__tile{display:flex;align-items:flex-start;flex-wrap: wrap; justify-content: center;}
                       `
                   }
               </style>
            </>
        )
    }
}
export default About