import React from 'react'
class PageNotFound extends React.Component{
    render(){
        return(
            <>
                <p>PageNotFound</p>
            </>
        )
    }
}
export default PageNotFound